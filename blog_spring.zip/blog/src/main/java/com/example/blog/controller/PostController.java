package com.example.blog.controller;

import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.blog.model.Comment;
import com.example.blog.model.Post;
import com.example.blog.model.User;
import com.example.blog.repository.UserRepository;
import com.example.blog.service.PostService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class PostController {
    private final PostService postService;
    private final UserRepository userRepository;

    @GetMapping("/posts")
    public String getPosts(Model model) {
        model.addAttribute("post", postService.getAllPost());
        return "posts.html";
    }

    @GetMapping("/post/create")
    public String getPostForm(Model model, Principal principal) {
        model.addAttribute("post", new Post());
        return "create-post.html";
    }

    @PostMapping("/post/create/new")
    public String postCreate(@Valid @ModelAttribute("post") Post dto,
            BindingResult result, Principal principal) {
        if (result.hasErrors()) {
            return "create-post.html";
        }
        User user = userRepository.findByUsername(principal.getName());
        postService.createPost(dto, user);
        return "redirect:/posts?successfully";
    }

    @GetMapping("/post/detail/{id}")
    public String getPostDetails(Model model, @PathVariable("id") int id) {
        model.addAttribute("post", postService.getPost(id));
        model.addAttribute("comment", new Comment());
        model.addAttribute("comments", postService.getAllComments(id));
        return "post-detail.html";
    }

    @GetMapping("/post/edit/{id}")
    public String getEditForm(@PathVariable("id") int id, Model model) {
        Post post = postService.getPost(id);
        model.addAttribute("post", post);
        return "post-edit.html";
    }

    @PostMapping("/post/edit/{id}/")
    public String postPostEdit(@Valid @ModelAttribute("post") Post dto,
            BindingResult result) {
        if (result.hasErrors())
            return "redirect:/post/edit/{id}?error=true";
        postService.updatePost(dto);
        return "redirect:/posts?update=successful";
    }

    @GetMapping("/post/delete/{id}")
    public String deletePost(@PathVariable("id") int id, Principal principal) {
        postService.deletePost(id, principal);
        return "redirect:/posts?delete=successful";
    }

    @PostMapping("/posts/{id}/like")
    public String postLike(@PathVariable("id") int id) {
        postService.addLike(id);
        return "redirect:/post/detail/{id}";
    }
}
