package com.example.blog.service;

import java.security.Principal;
import java.util.List;

import com.example.blog.model.Comment;
import com.example.blog.model.Post;
import com.example.blog.model.User;

public interface PostService {
    void createPost(Post dto, User user);

    void updatePost(Post dto);

    void deletePost(int id, Principal principal);

    Post getPost(int id);

    List<Post> getAllPost();

    void addLike(int id);

    List<Comment> getAllComments(int id);
}
