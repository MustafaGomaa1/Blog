package com.example.blog.controller;

import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.blog.model.Comment;
import com.example.blog.model.User;
import com.example.blog.repository.UserRepository;
import com.example.blog.service.CommentService;
import com.example.blog.service.PostService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class CommentController {
    private final CommentService commentService;
    private final PostService postService;
    private final UserRepository userRepository;

    @GetMapping("/comment/{id}/create")
    public String getCreateComment(Model model, @PathVariable int id) {
        model.addAttribute("comment", new Comment());
        model.addAttribute("post", postService.getPost(id));
        return "create-comment.html";
    }

    @PostMapping("/comment/{id}/create")
    public String createComment(@PathVariable("id") int id, @RequestParam("content") String content,
            @Valid @ModelAttribute("comment") Comment comment, BindingResult result, Principal principal) {
        if (result.hasErrors())
            return "redirect:/post/detail/{id}?comment=error";
        User user = userRepository.findByUsername(principal.getName());
        commentService.createComment(id, content, user);
        return "redirect:/post/detail/{id}?comment=successful";
    }
}
