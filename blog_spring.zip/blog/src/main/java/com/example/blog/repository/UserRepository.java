package com.example.blog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.blog.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {
    User findByUsername(String username);

}
