package com.example.blog.model;

public enum Tag {
    FOOD,
    SPORT,
    ACTION,
    SOCIAL,
    TECH,
    ENG
}
