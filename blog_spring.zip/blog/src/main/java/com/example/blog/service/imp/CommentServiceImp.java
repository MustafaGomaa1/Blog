package com.example.blog.service.imp;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.blog.model.Comment;
import com.example.blog.model.Post;
import com.example.blog.model.User;
import com.example.blog.repository.CommentRepository;
import com.example.blog.repository.PostRepository;
import com.example.blog.service.CommentService;

@Service
public class CommentServiceImp implements CommentService {

    private final CommentRepository commentRepository;
    private final PostRepository postRepository;

    public CommentServiceImp(CommentRepository commentRepository, PostRepository postRepository) {
        this.commentRepository = commentRepository;
        this.postRepository = postRepository;
    }

    @Override
    public void createComment(int id, String content, User user) {
        Comment comment = new Comment();
        comment.setContent(content);
        Post post = postRepository.findById(id).orElseThrow();
        List<Comment> comments = post.getComments();
        comments.add(comment);
        post.setComments(comments);
        postRepository.save(post);
        comment.setPost(post);
        comment.setUser(user);
        commentRepository.save(comment);
    }
}
