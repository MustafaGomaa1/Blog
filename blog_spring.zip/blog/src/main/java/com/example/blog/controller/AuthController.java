package com.example.blog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.blog.model.User;
import com.example.blog.service.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @GetMapping("/auth/register")
    public String getRegister(Model model) {
        model.addAttribute("user", new com.example.blog.model.User());
        return "register.html";
    }

    @PostMapping("/auth/register")
    public String postRegister(@Valid @ModelAttribute("user") User user, BindingResult result) {
        if (result.hasErrors()) {
            return "redirect:/auth/register?error=true";
        }
        try {
            userService.register(user);
            return "redirect:/auth/login";
        } catch (Exception e) {
            return "redirect:/auth/register?error";
        }
    }

    @GetMapping("/auth/login")
    public String getLogin() {
        return "login.html";
    }

}
