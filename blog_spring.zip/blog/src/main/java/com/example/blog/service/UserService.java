package com.example.blog.service;

import com.example.blog.model.User;

public interface UserService {

    void register(User user);
}
