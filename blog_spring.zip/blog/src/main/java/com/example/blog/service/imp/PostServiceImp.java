package com.example.blog.service.imp;

import java.security.Principal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.blog.model.Comment;
import com.example.blog.model.Post;
import com.example.blog.model.User;
import com.example.blog.repository.PostRepository;
import com.example.blog.service.PostService;

@Service
public class PostServiceImp implements PostService {
    private final PostRepository postRepository;

    public PostServiceImp(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    @Override
    public void createPost(Post dto, User user) {
        dto.setUser(user);
        postRepository.save(dto);
    }

    @SuppressWarnings("null")
    @Override
    public void updatePost(Post dto) {
        postRepository.save(dto);
    }

    @Override
    public void deletePost(int id, Principal principal) {
        Post post = postRepository.findById(id).orElseThrow();
        if (!post.getUser().getUsername().equals(principal.getName())) {
            throw new RuntimeException("runTime.html");
        }
        postRepository.deleteById(id);
    }

    @Override
    public Post getPost(int id) {
        return (postRepository.findById(id).orElseThrow());
    }

    @Override
    public List<Post> getAllPost() {
        return postRepository.findAll();
    }

    @Override
    public void addLike(int id) {
        Post post = postRepository.findById(id).orElseThrow();
        post.setLikes(post.getLikes() + 1);
        postRepository.save(post);
    }

    @Override
    public List<Comment> getAllComments(int id) {
        Post post = postRepository.findById(id).orElseThrow();
        return post.getComments();
    }
}
