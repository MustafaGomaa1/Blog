package com.example.blog.service;

import com.example.blog.model.User;

public interface CommentService {
    void createComment(int id, String content, User user);
}
